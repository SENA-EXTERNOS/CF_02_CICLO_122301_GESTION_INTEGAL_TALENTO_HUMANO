function ExecuteScript(strId)
{
  switch (strId)
  {
      case "67xDLQtYHTK":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

