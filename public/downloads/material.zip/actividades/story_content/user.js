function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ZsExm9TrB9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

